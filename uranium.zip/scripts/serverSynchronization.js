const
  uranium = global.uranium;

