const
  uranium = global.uranium;

uranium.createItem('armatura', {
  color: Color.valueOf('3b45dc')
});

uranium.createItem('aluminium_ore', {});
uranium.createItem('aluminium', {});
uranium.createItem('sulfur', {});
uranium.createItem('beton', {});
uranium.createItem('hard_beton', {});
uranium.createItem('bronze', {});
uranium.createItem('altit', {});
uranium.createItem('blue_thorium', {});
uranium.createItem('uranium-238', {});
uranium.createItem('uranium-235', {});
uranium.createItem('uranium_brick', {});
uranium.createItem('uranium-fuel-cell', {});
uranium.createItem('iridium', {});
uranium.createItem('tritium', {});
uranium.createItem('iritrium', {});
uranium.createItem('ART_sleeve', {
  color: Color.valueOf(uranium.ammo_colors[0])
});
uranium.createItem('order_core', {});
uranium.createItem('greatness_core', {});
