const
  uranium = global.uranium;

uranium
  .createBuild("GenericCrafter", "_beton_forge", {});

uranium
  .createBuild("GenericCrafter", "_hard_beton_forge", {});

uranium
  .createBuild("GenericCrafter", "_armatura_forge", {});

uranium
  .createBuild("GenericCrafter", "aluminium_forge", {});