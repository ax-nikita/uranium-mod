let
  uranium = require("uranium");

require("customJSON");

require("items");
require("ammo");
require("effects");
require("statusEffects");
require("bullets");
require("createTurret");
require("turretQuality");
require("customBuilds");
require("multiCrafter");

require("rotors");
require("wall");
require("turret");
require("powerAeff");
require("baseCraft");
require("ammocraft");
require("new_texture");
require("uraniumTier");
require("ores");

//1й тир

